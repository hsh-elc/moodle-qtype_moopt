-- VARIANTS 1

-- DBS1.QUICKTEST::0::
-- Vor- und Nachname aller Mitarbeiter.
SELECT first_name, last_name
FROM hr.employees;

