public class Rotation {
    public static void main(String[] args) {
        int x= 2;
        int y= 3;

        int tmp= x;
        x= y;
        y= -tmp;
        
        System.out.println(x + " " + y);
	}
}