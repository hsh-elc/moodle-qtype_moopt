public class Turn {
    public static void main(String[] args) {
        int x= 2; // This must not be changed
        /* Never change the following line: // */ 
        int y= 3; 

        x= y;  System.out.println("Test: "+x); // swap part 1
        y= -x; // and part 2
        
        // output
        System.out./* now print it */ println(x + " " + y);
	}
}