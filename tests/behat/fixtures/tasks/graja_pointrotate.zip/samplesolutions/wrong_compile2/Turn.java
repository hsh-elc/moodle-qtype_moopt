public class $(cn)$ {
    public static void main(String[] args) {
        int x= 2;
        int y= 3;

        int[] vec397502; // bad
        int tmp= y;
        y= x;
        x= -tmp;
        
        System.out.println(x + " " + y);
	}
}