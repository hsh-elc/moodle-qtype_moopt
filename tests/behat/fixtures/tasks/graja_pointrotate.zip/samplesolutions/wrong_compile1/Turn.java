public class Turn {
    public static void main(String[] args) {
        int x= 2;
        int y= 3;

        Class<?> c= Turn.class; // dummy, but works not in generated class.
        int tmp= y;
        y= x;
        x= -tmp;
        
        System.out.println(x + " " + y);
	}
}