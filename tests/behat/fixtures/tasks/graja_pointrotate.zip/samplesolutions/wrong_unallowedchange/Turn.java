public class Turn {
    public static void main(String[] args) {
        int x= 2;
        int tmp=3;
        int y= 3;

        y= x;
        x= -tmp;

        System.out.println(x + " " + y);
	}
}