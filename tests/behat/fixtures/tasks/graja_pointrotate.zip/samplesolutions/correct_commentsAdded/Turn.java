/** This is a perfect solution. */
public class Turn {
    /**
     * Main program.
     */
    public static void main(String[] args) {
        int x= 2; // This must not be changed
        /* Never change the following line: // */ 
        int y= 3; 

        int tmp= y;
        y= x;
        x= -tmp;
        
        // output
        System.out./* now print it */ println(x + " " + y);
	}
}
// End of program
