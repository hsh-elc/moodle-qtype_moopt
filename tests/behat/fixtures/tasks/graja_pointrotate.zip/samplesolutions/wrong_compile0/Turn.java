public class Turn {
    public static void main(String[] args) {
        int x= 2;
        int y= 3;

        int tmp= Y;
        y= x;
        x= -tmp;
        
        System.out.println(x + " " + y);
	}
}