public class Turn {
    public static void main(String[] args) {
        int x= 2;
        int y= 3;

        y= 2;
        x= -3;
        
        System.out.println(x + " " + y);
	}
}