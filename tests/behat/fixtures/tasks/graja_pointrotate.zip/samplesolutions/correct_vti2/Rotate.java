public class Rotate {
    public static void main(String[] args) {
        int x= 4;
        int y= 5;

        int tmp= x;
        x= -y;
        y= tmp;
        
        System.out.println(x + " " + y);
	}
}